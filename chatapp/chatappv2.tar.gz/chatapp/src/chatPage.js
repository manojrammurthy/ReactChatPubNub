"use strict";

var React = require('react');

var ChatHead = React.createClass({
	render:function(){
		return (
			<div className="message-form">
			<h1>Heading</h1>
			</div>
			);
	}
});

var ChatBody = React.createClass({
	render:function(){
		var conHeight={
						'minHeight': 535
			};
			var UUID = this.props.user;
			var messageList = this.props.data.map(function(message,index){
				return(
					<div className="media" key={index}>
							<a href="#" className="pull-left">        
          <img alt="64x64" data-src="holder.js/64x64" className="media-object img-thumbnail"  src="http://placehold.it/64x64" />      
        			</a>
			        <div className="media-body">
			          <h3 className="media-heading"><strong><a href="#">{UUID}</a></strong></h3>
			          <p className="small"><span  className="glyphicon glyphicon-star" >{message.createdTime}</span></p>
			          <p>{message.message}</p>
			        </div>
			        </div>
					);

			});
		return (
				<div className="container" style={conHeight}>
  					<div className="row">
    				<div className="col-lg-12"> 
    				{messageList}       		 	
    				</div>
    				</div>
  				</div>

			);
	}
});

var ChatForm = React.createClass({

	handleSubmit:function(e)
	{
		e.preventDefault();
		var message = this.refs.Message.value.trim();
		var time = new Date().getTime(),
		date = new Date(time),
		datestring = date.toString();
		if(!message){
			return;
		}
		this.props.onMessageSubmit({message: message,createdTime:datestring});
        this.refs.Message.value='';
        return;	
	},
	
	render:function(){
		
		return (
				<div className="message-form">
				<div className="container">
				<div className="row">
				<form role="form" style={{padding: 30 + 'px'}} onSubmit= {this.handleSubmit} >
				<div className="input-field col-sm-6">
				    <div className="form-group " >
				      <input type="text" className="form-control" ref="Message" placeholder="Type your message" />
				    </div>	
				</div>
				<div className="col-sm-2">
					<button type="submit" className="btn btn-default ">Send</button>
				</div>			
				</form>			   
				</div>
				</div>
				</div>
			);
	}
})

var Main = React.createClass({
	handleMessageSubmit :function(message){
	var messages = this.state.data;
    var newMessages = messages.concat([message]);
    this.setState({data:newMessages});
	},

	getInitialState: function() {
    return {data: [],user:Math.floor(Math.random()*90000) + 10000};
  },
 randomNumber:function(){
 	var rand = 1000;
 	return rand;
 },
	render:function(){
		return (
			<div >
				<ChatHead />
				<ChatBody data ={this.state.data} user = {this.state.user} />
				<ChatForm onMessageSubmit={this.handleMessageSubmit} />
				</div>
			);
	}
});

module.exports = Main;