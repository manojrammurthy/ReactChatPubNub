$ = Jquery = require('jquery');

var React = require('react');
var ReactDOM  = require('react-dom');
var Chat = require('./chatPage');

ReactDOM.render(<Chat />,document.getElementById('app'));